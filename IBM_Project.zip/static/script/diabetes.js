function showPreg(){
    console.log("heih");
    let pregDiv = document.querySelector('.pregnant')
    pregDiv.style.display = 'block'
}
  function hidePreg(){
    let pregDiv = document.querySelector('.pregnant')
    pregDiv.style.display = 'none'
}
