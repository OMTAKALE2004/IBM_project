
t1 = gsap.timeline()
t2 = gsap.timeline()
t1.from('.card1',{
    y:"-90vh"
})
t2.from('.card2',{
    y:"90vh"
})